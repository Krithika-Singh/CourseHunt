package com.ts.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.ts.dao.StudentDAO;
import com.ts.dto.Student;

@WebServlet("/StudentUpdateServlet")
public class StudentUpdateServlet extends HttpServlet {
	private Connection con = null;
	private PreparedStatement pst = null;
		
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		System.out.println("Inside StudentUpdateServlet file");
		try{
			System.out.println("Inside StudentUpdateServlet file try");
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			int sid = Integer.parseInt(request.getParameter("stuId"));
			String studname = request.getParameter("sname");
			String email = request.getParameter("email");
			System.out.println("Inside StudentUpdateServlet file try");
			Long contact = Long.parseLong(request.getParameter("contact"));
			String location = request.getParameter("location");
			System.out.println("Inside StudentUpdateServlet file try");
			Student stud = new Student();
			stud.setStuId(sid);
			stud.setSname(studname);
			stud.setEmail(email);
			stud.setContact(contact);
			stud.setLocation(location);
			System.out.println("Inside StudentUpdateServlet file try before dao");
			int x = new StudentDAO().editStudent(stud);
			System.out.println("StudentUpdateServlet file "+ x);
			if(x > 0){
				RequestDispatcher rd = request.getRequestDispatcher("kstudentpanel.jsp");
				rd.include(request, response);
				//out.println("<center><h2>Updated Successfully:)</h2></center>");
				//out.println("Updated Successfully!");
			}
		} catch(Exception e){
			e.getMessage();
		}
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}


}
