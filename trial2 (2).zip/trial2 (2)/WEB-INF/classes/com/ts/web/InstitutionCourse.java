package com.ts.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ts.dao.InstituteDAO;
import com.ts.dao.LoginRegister;
import com.ts.dto.Institution;

@WebServlet("/InstitutionCourse")
public class InstitutionCourse extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		    HttpSession session = request.getSession();
		    String username = (String) session.getAttribute("name");
		    String password = (String) session.getAttribute("pwd");
		    
		    LoginRegister lrdao = new LoginRegister();
		    Institution institute = new Institution();
		    institute=lrdao.loginInst(username, password);
		    int instId = institute.getInstId();
		    System.out.println("institution id = "+instId);
		    
		    PrintWriter out=response.getWriter();
		    response.setContentType("text/html");
		    String[] courses=request.getParameterValues("course");
		    String[] duration=request.getParameterValues("Cduration");
		    String[] fee=request.getParameterValues("CFee");
		    
		    
		    ArrayList<Integer> list1 =new ArrayList<Integer>();
		    ArrayList<String> list2 =new ArrayList<String>();
		    ArrayList<Integer> list3 =new ArrayList<Integer>();
		    
		    for(String s1:courses) {
			  list1.add(Integer.parseInt(s1));
		    }
		    System.out.println(list1);
		    for(String s2:duration) {
		    	if(!(s2.equals(""))) {
				  list2.add((s2));
		    	}
		    }
			System.out.println(list2);
			for(String s3:fee) {
				if(!(s3.equals(""))) {
				  list3.add(Integer.parseInt(s3));
				}
			}
				
		    System.out.println(list3);
		    
		    out.println("<html>");
		    for(int i = 0; i < list1.size();i++) {
		    	lrdao.courseOffedByInstitution(instId,list1.get(i),list2.get(i),list3.get(i));
		    }
			out.println("<body> Institution Registered Successfully</body>");
	    	RequestDispatcher dispatcher=request.getRequestDispatcher("khome.html"); //"kInstitutePanel.jsp");
	    	dispatcher.forward(request, response);
	    	out.println("</html>");
		    
		  
	        
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request,response);
	      
	}

}
