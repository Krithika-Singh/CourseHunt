package com.ts.web;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ts.dao.AdminDAO;
import com.ts.dao.InstituteDAO;
import com.ts.dao.LoginRegister;
import com.ts.dto.Admin;
import com.ts.dto.Institution;
@WebServlet("/Admin_Institutes_Servlet")
public class Admin_Institutes_Servlet extends HttpServlet {
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		String username = (String)session.getAttribute("loggedUser");
		String password = (String)session.getAttribute("pwd");
		System.out.println(username+" " + password );
	   AdminDAO dao = new AdminDAO();
	   ArrayList<Institution> list = new ArrayList<Institution>();
	   list = dao.AllInstitutes();  
	   System.out.println(list);
	   request.setAttribute("Inst", list);
	   RequestDispatcher dispatcher=request.getRequestDispatcher("AdminInstitutes.jsp");
	   dispatcher.forward(request, response);	
	  
	   
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
