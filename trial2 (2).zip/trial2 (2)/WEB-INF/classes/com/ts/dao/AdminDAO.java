package com.ts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ts.dbutility.DBConnection;
import com.ts.dto.Student;
import com.ts.dto.student_course;
import com.ts.dto.Courses;
import com.ts.dto.Institution;
public class AdminDAO {
	public ArrayList<Student> AllStudents(){
		ArrayList<Student> list=new ArrayList<>();
		
		PreparedStatement pst = null;
		ResultSet rst = null;
	final String selection = "select * from student;";
	try{
		Connection con = DBConnection.getConnection();
		pst = con.prepareStatement(selection);
		rst = pst.executeQuery();
		while(rst.next()){
			Student student=new Student();
			student.setStuId(rst.getInt(1));
			student.setSname(rst.getString(2));
			student.setUserName(rst.getString(3));
			student.setPassword(rst.getString(4));
			student.setEmail(rst.getString(5));
			student.setContact(rst.getLong(6));
			student.setLocation(rst.getString(7));
			list.add(student);
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return list;
	}
	
	public ArrayList<Institution> AllInstitutes(){
		ArrayList<Institution> list=new ArrayList<>();
		
		PreparedStatement pst = null;
		ResultSet rst = null;
		Institution institute = null;
	final String selection = "select * from institute;";
	try{
		Connection con = DBConnection.getConnection();
		pst = con.prepareStatement(selection);
		rst = pst.executeQuery();
		while(rst.next()){
			institute=new Institution();
			institute.setInstId(rst.getInt(1));
			institute.setIname(rst.getString(2));
			institute.setUserName(rst.getString(3));
			institute.setPassword(rst.getString(4));
			institute.setEmail(rst.getString(5));
			institute.setContact(rst.getLong(6));
			institute.setLocation(rst.getString(7));
			institute.setTiming(rst.getString(8));
			institute.setVacancy(rst.getInt(9));			
			list.add(institute);
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return list;
	}
    
	public ArrayList<Courses> AllCourses(){
		ArrayList<Courses> list=new ArrayList<>();
		
		PreparedStatement pst = null;
		ResultSet rst = null;
		Courses courses = null;
	final String selection = "select * from courses;";
	try{
		Connection con = DBConnection.getConnection();
		pst = con.prepareStatement(selection);
		rst = pst.executeQuery();
		while(rst.next()){
			courses=new Courses();
			courses.setCourseId(rst.getInt(1));
			courses.setCourseName(rst.getString(2));	
			list.add(courses);
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return list;
	}
}
