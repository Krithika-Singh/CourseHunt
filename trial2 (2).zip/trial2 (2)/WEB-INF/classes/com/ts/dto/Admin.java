package com.ts.dto;

public class Admin {
	private String Aname;
	private String Ausername;
	private String Apassword;
	private String Acreationdate;
	
	public String getAname() {
		return Aname;
	}
	public void setAname(String aname) {
		Aname = aname;
	}
	public String getAusername() {
		return Ausername;
	}
	public void setAusername(String ausername) {
		Ausername = ausername;
	}
	public String getApassword() {
		return Apassword;
	}
	public void setApassword(String apassword) {
		Apassword = apassword;
	}
	public String getAcreationdate() {
		return Acreationdate;
	}
	public void setAcreationdate(String acreationdate) {
		Acreationdate = acreationdate;
	}

	@Override
	public String toString() {
		return "Admin [Name = " + Aname + ",username = " + Ausername + ",password = " + Apassword + ",Creation date = " + Acreationdate + "]";
	}
}
