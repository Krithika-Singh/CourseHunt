package com.ts.dto;

import java.util.ArrayList;

import java.util.List;



public class inst_course{

private int instId;
private String iname;
private String userName;
private String password;
private String email;
private long contact;
private String location;
private String timing;
private int vacancy;
private String cduration;
private int fees;

public int getInstId() {
	return instId;
}

public int getFees() {
	return fees;
}

public void setFees(int fees) {
	this.fees = fees;
}

public void setInstId(int instId) {
	this.instId = instId;
}


public String getIname() {
	return iname;
}

public void setIname(String iname) {
	this.iname = iname;
}

public String getTiming() {
	return timing;
}

public void setTiming(String timing) {
	this.timing = timing;
}


public String getUserName() {
	return userName;
}

public void setUserName(String userName) {
	this.userName = userName;
}
public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}
public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}
public long getContact() {
	return contact;
}

public void setContact(long contact) {
	this.contact = contact;
}
public String getLocation() {
	return location;
}

public void setLocation(String location) {
	this.location = location;
}

public int getVacancy() {
	return vacancy;
}

public void setVacancy(int vacancy) {
	this.vacancy = vacancy;
}

public String getCduration() {
	return cduration;
}

public void setCduration(String cduration) {
	this.cduration = cduration;
}

/*public int getCFee() {
	return fees;
}

public void setCFee(int cFee) {
	this.fees = cFee;
}*/




@Override
public String toString() {
	return "Inst_courses dto [instId = " + instId + ",iName = " + iname + ",userName = " + userName + ",password = " + password + ",email = " + email + ",contact = " + contact + ",location = " + location + ", timings=" + timing + ", vacancy=" + vacancy +",Duration = " + cduration + ",Fee = "+fees+"]";
}
}

